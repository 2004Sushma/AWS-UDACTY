S3 Website Endpoint:
http://sushma-travel-blog-2026-12345.s3-website-us-east-1.amazonaws.com

CloudFront URL:
https://d1z5xt83mzuxcx.cloudfront.net